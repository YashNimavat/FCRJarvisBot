import React from 'react';

const Landing = () => (
    <div style={{ textAlign: 'center' }}>
        <h1>Fotography Club of Rajkot</h1>
        
        </div>
)

export default Landing;