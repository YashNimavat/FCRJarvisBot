import React from 'react';
import ItemList from './ItemList';

const Shop = () => (
    <div>
        <h1>Shop</h1>
        <ItemList />
    </div>
)

export default Shop;